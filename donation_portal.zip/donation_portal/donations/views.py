# donations/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from .models import DonationRequest, DonationResponse
from .forms import DonationRequestForm, DonationResponseForm

@login_required
def dashboard(request):
    """Show all APPROVED requests from OTHER users (not current user's own requests)"""
    
    # Get approved requests that belong to OTHER users
    approved_requests = DonationRequest.objects.filter(
        status='Approved'  # Only show approved requests
    ).exclude(
        user=request.user  # Exclude current user's own requests
    ).select_related('user').prefetch_related('responses').order_by('-created_at')
    
    # Apply filters if provided
    category_filter = request.GET.get('category')
    if category_filter:
        approved_requests = approved_requests.filter(category=category_filter)
    
    location_filter = request.GET.get('location')
    if location_filter:
        approved_requests = approved_requests.filter(location__icontains=location_filter)
    
    # Get which requests the current user has already responded to
    user_response_request_ids = []
    if approved_requests.exists():
        user_response_request_ids = DonationResponse.objects.filter(
            user=request.user,
            request_id__in=approved_requests.values_list('id', flat=True)
        ).values_list('request_id', flat=True)
    
    context = {
        'requests': approved_requests,
        'categories': DonationRequest.CATEGORY_CHOICES,
        'user_responses': list(user_response_request_ids),
        'category_filter': category_filter,
        'location_filter': location_filter,
    }
    return render(request, 'donations/dashboard.html', context)

@login_required
def create_request(request):
    """Create a new donation request"""
    if request.method == 'POST':
        form = DonationRequestForm(request.POST)
        if form.is_valid():
            donation_request = form.save(commit=False)
            donation_request.user = request.user
            donation_request.save()
            messages.success(request, '✅ Your donation request has been submitted! It needs admin approval before others can see it.')
            return redirect('my_requests')
    else:
        form = DonationRequestForm()
    
    return render(request, 'donations/create_request.html', {'form': form})

@login_required
def my_requests(request):
    """Show current user's own requests"""
    requests = DonationRequest.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'donations/my_requests.html', {'requests': requests})

@login_required
def request_detail(request, request_id):
    """View request details and handle responses"""
    donation_request = get_object_or_404(DonationRequest, id=request_id)
    
    # Check permissions: User can view if:
    # 1. They own the request, OR
    # 2. The request is approved
    if donation_request.user != request.user and donation_request.status != 'Approved':
        messages.error(request, '⛔ You cannot view this request. It is not approved yet.')
        return redirect('dashboard')
    
    # Get all responses for this request
    responses = donation_request.responses.all().order_by('-created_at')
    
    # Check if current user has already responded (only if they're not the owner)
    user_has_responded = False
    if donation_request.user != request.user:
        user_has_responded = responses.filter(user=request.user).exists()
    
    # Handle response submission
    if request.method == 'POST':
        if 'respond' in request.POST:
            # Validate response submission
            if donation_request.user == request.user:
                messages.error(request, '❌ You cannot respond to your own request.')
            elif donation_request.status != 'Approved':
                messages.error(request, '❌ This request is not approved yet.')
            elif user_has_responded:
                messages.error(request, '❌ You have already responded to this request.')
            else:
                response_form = DonationResponseForm(request.POST)
                if response_form.is_valid():
                    response = response_form.save(commit=False)
                    response.request = donation_request
                    response.user = request.user
                    response.save()
                    messages.success(request, '✅ Your response has been submitted! The requester will contact you.')
                    return redirect('request_detail', request_id=request_id)
                else:
                    messages.error(request, '❌ Please fill all required fields correctly.')
    
    response_form = DonationResponseForm()
    
    context = {
        'donation_request': donation_request,
        'responses': responses,
        'user_has_responded': user_has_responded,
        'response_form': response_form,
        'can_respond': (
            donation_request.user != request.user and 
            donation_request.status == 'Approved' and 
            not user_has_responded
        ),
        'is_owner': donation_request.user == request.user,
    }
    return render(request, 'donations/request_detail.html', context)

@login_required
def my_responses(request):
    """Show user's responses (both made and received)"""
    # Responses user has made to others' requests
    responses_made = DonationResponse.objects.filter(
        user=request.user
    ).select_related('request', 'request__user').order_by('-created_at')
    
    # Responses others have made to user's requests
    responses_received = DonationResponse.objects.filter(
        request__user=request.user
    ).select_related('request', 'user').order_by('-created_at')
    
    context = {
        'responses_made': responses_made,
        'responses_received': responses_received,
    }
    return render(request, 'donations/my_responses.html', context)

@login_required
def update_response_status(request, response_id):
    """Request owner can accept/reject responses"""
    response = get_object_or_404(DonationResponse, id=response_id)
    
    # Only request owner can update response status
    if response.request.user != request.user:
        messages.error(request, '⛔ You do not have permission to update this response.')
        return redirect('my_responses')
    
    if request.method == 'POST':
        new_status = request.POST.get('status')
        if new_status in ['Accepted', 'Rejected', 'Completed']:
            response.status = new_status
            response.save()
            
            # If accepted, update request status to fulfilled
            if new_status == 'Accepted':
                response.request.status = 'Fulfilled'
                response.request.save()
                messages.success(request, '✅ Response accepted! The request is now marked as fulfilled.')
            else:
                messages.success(request, f'✅ Response status updated to {new_status}.')
    
    return redirect('my_responses')

@login_required
def delete_request(request, request_id):
    """Delete a request (only by owner)"""
    donation_request = get_object_or_404(DonationRequest, id=request_id)
    
    # Only request owner can delete
    if donation_request.user != request.user:
        messages.error(request, '⛔ You do not have permission to delete this request.')
        return redirect('my_requests')
    
    if request.method == 'POST':
        donation_request.delete()
        messages.success(request, '✅ Your donation request has been deleted.')
        return redirect('my_requests')
    
    return render(request, 'donations/delete_request.html', {'request': donation_request})