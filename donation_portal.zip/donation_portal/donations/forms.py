# donations/forms.py
from django import forms
from .models import DonationRequest, DonationResponse

class DonationRequestForm(forms.ModelForm):
    class Meta:
        model = DonationRequest
        fields = ['category', 'quantity', 'location', 'description', 'contact_info', 'urgency']
        widgets = {
            'description': forms.Textarea(attrs={
                'rows': 4, 
                'placeholder': 'Describe your need in detail...',
                'class': 'form-control'
            }),
            'contact_info': forms.TextInput(attrs={
                'placeholder': 'Phone/Email for contact',
                'class': 'form-control'
            }),
            'location': forms.TextInput(attrs={
                'placeholder': 'City, Area, Landmark',
                'class': 'form-control'
            }),
            'quantity': forms.TextInput(attrs={
                'placeholder': 'e.g., 2 units, ₹5000, 5 kgs',
                'class': 'form-control'
            }),
            'category': forms.Select(attrs={'class': 'form-control'}),
            'urgency': forms.Select(attrs={'class': 'form-control'}),
        }
        labels = {
            'contact_info': 'Contact Information',
            'urgency': 'Urgency Level',
        }

class DonationResponseForm(forms.ModelForm):
    class Meta:
        model = DonationResponse
        fields = ['message', 'contact_info', 'can_help_with']
        widgets = {
            'message': forms.Textarea(attrs={
                'rows': 4, 
                'placeholder': 'Tell them how you can help...',
                'class': 'form-control'
            }),
            'contact_info': forms.Textarea(attrs={
                'rows': 3,
                'placeholder': 'Your contact details (phone, email, etc.)',
                'class': 'form-control'
            }),
            'can_help_with': forms.TextInput(attrs={
                'placeholder': 'e.g., I can donate ₹2000, I have 5 shirts, etc.',
                'class': 'form-control'
            }),
        }
        labels = {
            'can_help_with': 'What you can offer',
            'contact_info': 'Your contact details',
        }