# donations/models.py
from django.db import models
from django.contrib.auth.models import User

class DonationRequest(models.Model):
    BLOOD = 'Blood'
    FUNDS = 'Funds'
    CLOTHES = 'Clothes'
    FOOD = 'Food'
    SAPLINGS = 'Saplings'
    
    CATEGORY_CHOICES = [
        (BLOOD, 'Blood'),
        (FUNDS, 'Funds'),
        (CLOTHES, 'Clothes'),
        (FOOD, 'Food'),
        (SAPLINGS, 'Saplings'),
    ]
    
    URGENCY_LOW = 'Low'
    URGENCY_MEDIUM = 'Medium'
    URGENCY_HIGH = 'High'
    URGENCY_CRITICAL = 'Critical'
    
    URGENCY_CHOICES = [
        (URGENCY_LOW, 'Low'),
        (URGENCY_MEDIUM, 'Medium'),
        (URGENCY_HIGH, 'High'),
        (URGENCY_CRITICAL, 'Critical')
    ]
    
    STATUS_PENDING = 'Pending'
    STATUS_APPROVED = 'Approved'
    STATUS_FULFILLED = 'Fulfilled'
    STATUS_REJECTED = 'Rejected'
    
    STATUS_CHOICES = [
        (STATUS_PENDING, 'Pending'),
        (STATUS_APPROVED, 'Approved'),
        (STATUS_FULFILLED, 'Fulfilled'),
        (STATUS_REJECTED, 'Rejected'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='donation_requests')
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    quantity = models.CharField(max_length=50)
    location = models.CharField(max_length=100)
    description = models.TextField()
    contact_info = models.CharField(max_length=200, blank=True, null=True)
    urgency = models.CharField(max_length=20, choices=URGENCY_CHOICES, default=URGENCY_MEDIUM)
    
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_PENDING
    )
    
    admin_remark = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.category} | {self.user.username} | {self.status}"
    
    def get_response_count(self):
        return self.responses.count()


class DonationResponse(models.Model):
    STATUS_PENDING = 'Pending'
    STATUS_ACCEPTED = 'Accepted'
    STATUS_COMPLETED = 'Completed'
    STATUS_REJECTED = 'Rejected'
    
    STATUS_CHOICES = [
        (STATUS_PENDING, 'Pending'),
        (STATUS_ACCEPTED, 'Accepted'),
        (STATUS_COMPLETED, 'Completed'),
        (STATUS_REJECTED, 'Rejected')
    ]
    
    request = models.ForeignKey(DonationRequest, on_delete=models.CASCADE, related_name='responses')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='donation_responses')
    message = models.TextField()
    contact_info = models.TextField()
    can_help_with = models.CharField(max_length=100)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Response by {self.user.username} for {self.request.category}"