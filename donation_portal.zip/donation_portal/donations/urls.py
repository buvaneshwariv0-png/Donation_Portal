# donations/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('create/', views.create_request, name='create_request'),
    path('my-requests/', views.my_requests, name='my_requests'),
    path('request/<int:request_id>/', views.request_detail, name='request_detail'),
    path('my-responses/', views.my_responses, name='my_responses'),
    path('response/<int:response_id>/update/', views.update_response_status, name='update_response_status'),
    path('request/<int:request_id>/delete/', views.delete_request, name='delete_request'),
]