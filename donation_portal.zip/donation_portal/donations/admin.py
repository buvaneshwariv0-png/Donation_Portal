# donations/admin.py
from django.contrib import admin
from .models import DonationRequest, DonationResponse

class DonationResponseInline(admin.TabularInline):
    model = DonationResponse
    extra = 0
    readonly_fields = ('created_at',)
    fields = ('user', 'message', 'contact_info', 'can_help_with', 'status', 'created_at')

@admin.register(DonationRequest)
class DonationRequestAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'category', 'quantity', 'location', 'urgency', 'status', 'created_at', 'response_count')
    list_filter = ('category', 'status', 'location', 'urgency')
    search_fields = ('user__username', 'location', 'category', 'description')
    list_editable = ('status',)
    readonly_fields = ('created_at', 'updated_at', 'response_count')
    fieldsets = (
        ('Request Details', {
            'fields': ('user', 'category', 'quantity', 'location', 'description', 'contact_info', 'urgency')
        }),
        ('Admin Control', {
            'fields': ('status', 'admin_remark')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    inlines = [DonationResponseInline]
    
    def response_count(self, obj):
        return obj.get_response_count()
    response_count.short_description = 'Responses'

@admin.register(DonationResponse)
class DonationResponseAdmin(admin.ModelAdmin):
    list_display = ('id', 'request', 'user', 'can_help_with', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('user__username', 'request__category', 'message')
    readonly_fields = ('created_at',)